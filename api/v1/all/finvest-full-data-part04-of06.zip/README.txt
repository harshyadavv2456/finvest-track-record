FinVest Track Record - data API download
============================================

For educational and research purposes only. Not investment advice. Research/educational track record of a quantitative model. Not investment advice. Not a SEBI-registered research analyst or adviser. Past performance does not guarantee future returns.

Model long signals (INITIATE/ADD) are shown for educational purposes only: These long-signal analyses are model outputs shown for testing and educational purposes only. Not investment advice, not a recommendation to buy or sell.

Yahoo Finance-sourced price data, provided for internal/educational use only; Yahoo's redistribution terms may apply. No warranty; adjusted for splits and dividends as served by Yahoo. (folder prices/)

This part holds 7 files: ticker/US/detail/YUM.json.gz ... ticker/US/detail/ZTS.json.gz

Kind: FULL data bundle (all published API files incl. prices) - part 4 of 6
Layout: same paths as https://harshyadavv2456.github.io/finvest-track-record/api/v1/ (open index.json for the catalogue and field dictionary fields.json).
Long signals of a signal day are published only after the entry session closes + 45 minutes (SEBI-style lock); locked names are absent from every file.
Prices: prices/{MARKET}/{file}.csv.gz (gzip CSV with # comment lines) - read with pandas.read_csv(path, comment="#").
Source: FinVest public API + this tracker. Attribution required. Not guaranteed.
Generated: 2026-10-31
